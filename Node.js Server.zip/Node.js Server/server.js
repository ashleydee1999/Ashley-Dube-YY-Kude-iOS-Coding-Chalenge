var app = require('express')();
var http = require('http').Server(app);
var io = require('socket.io')(http);

var userList = [];
var typingUsers = {};

app.get('/', function(req, res){
  res.send('<h1>AshDube Chat App Server</h1>');
});


http.listen(3000, function(){
  console.log('Server is running on port: 3000');
});


io.on('connection', function(clientSocket){
  console.log('New User Connection');

  clientSocket.on('disconnect', function(){
    console.log('A User has disconnected');

    var theUsername;
    for (var i=0; i<userList.length; i++) {
      if (userList[i]["id"] == clientSocket.id) {
        userList[i]["isConnected"] = false;
        theUsername = userList[i]["userName"];
        break;
      }
    }

    io.emit("userList", userList);
    io.emit("userExitUpdate", theUsername);
  });


  clientSocket.on('chatMessage', function(theUsername, message){
    var currentDateTime = new Date().toLocaleString();
    delete typingUsers[theUsername];
    io.emit('newChatMessage', theUsername, message, currentDateTime);
  });

  clientSocket.on("exitUser", function(theUsername){
    for (var i=0; i<userList.length; i++) {
      if (userList[i]["id"] == clientSocket.id) {
        userList.splice(i, 1);
        break;
      }
    }
    io.emit("userExitUpdate", theUsername);
  });

  clientSocket.on("connectUser", function(theUsername) {
      var message = theUsername + " has Connected.";
      console.log(message);

      var userInfo = {};
      var foundUser = false;
      for (var i=0; i<userList.length; i++) {
        if (userList[i]["userName"] == theUsername) {
          userList[i]["isConnected"] = true
          userList[i]["id"] = clientSocket.id;
          userInfo = userList[i];
          foundUser = true;
          break;
        }
      }

      if (!foundUser) {
        userInfo["id"] = clientSocket.id;
        userInfo["userName"] = theUsername;
        userInfo["isConnected"] = true
        userList.push(userInfo);
      }

      io.emit("userList", userList);
      io.emit("userConnectUpdate", userInfo)
  });

});
